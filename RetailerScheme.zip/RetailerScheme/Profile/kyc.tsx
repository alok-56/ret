import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  Alert,
  ActivityIndicator,
  Image,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Headercomponent } from '../../../Components';
import { useTranslation } from 'react-i18next';
import { TextInput } from 'react-native-gesture-handler';
import { AppStyle } from '../../../config/Style';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { shallowEqual, useSelector } from 'react-redux';
import { SendKycOtp, VerifyKycOtp } from '../../../ApiServices/httpServices';

const Kyc = () => {
  const { t } = useTranslation();
  const [aadharNumber, setAadharNumber] = useState('');
  const [otp, setOtp] = useState('');
  const [refId, setRefId] = useState('');
  const [loading, setLoading] = useState(false);
  const [otpSent, setOtpSent] = useState(false);
  const [verified, setVerified] = useState(false);
  const [verifiedData, setVerifiedData] = useState<any>(null);

  const profileDetail = useSelector(
    (state: any) => state.auth.profileData,
    shallowEqual,
  );

  // Validate Aadhaar number (12 digits)
  const validateAadhar = (number: string) => {
    return /^\d{12}$/.test(number);
  };

  // Send OTP
  const handleSendOtp = async () => {
    if (!validateAadhar(aadharNumber)) {
      Alert.alert(
        'Invalid Aadhaar',
        'Please enter a valid 12-digit Aadhaar number',
      );
      return;
    }

    setLoading(true);
    try {
      const payload = {
        RetailerCode: profileDetail.retailerCode,
        AadharNumber: aadharNumber,
      };

      const response: any = await SendKycOtp(payload);

      if (response.status && response.data) {
        setRefId(response.data.ref_id);
        setOtpSent(true);
        Alert.alert('Success', response.message || 'OTP sent successfully');
      } else {
        Alert.alert('Error', response.message || 'Failed to send OTP');
      }
    } catch (error) {
      console.error('Error sending OTP:', error);
      Alert.alert('Error', 'Failed to send OTP. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // Verify OTP
  const handleVerifyOtp = async () => {
    if (!otp || otp.length !== 6) {
      Alert.alert('Invalid OTP', 'Please enter a valid 6-digit OTP');
      return;
    }

    setLoading(true);
    try {
      const payload = {
        AadharNumber: aadharNumber,
        Retailercode: profileDetail.retailerCode,
        Refid: refId,
        Otp: otp,
      };

      const response: any = await VerifyKycOtp(payload);

      if (response.status && response.data) {
        setVerified(true);
        setVerifiedData(response.data);
        Alert.alert('Success', 'KYC verification completed successfully!');
      } else {
        Alert.alert('Error', response.message || 'Failed to verify OTP');
      }
    } catch (error) {
      console.error('Error verifying OTP:', error);
      Alert.alert('Error', 'Failed to verify OTP. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // Reset form
  const handleReset = () => {
    setAadharNumber('');
    setOtp('');
    setRefId('');
    setOtpSent(false);
    setVerified(false);
    setVerifiedData(null);
  };

  // Show verified details
  if (verified && verifiedData) {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: '#F7F7F7' }}>
        <Headercomponent type={'2'} name={t('KYC Verification')} />
        <View style={styles.container}>
          <View style={styles.successSection}>
            <Icon name="check-circle" size={80} color="#4CAF50" />
            <Text style={styles.successTitle}>Verification Successful!</Text>
          </View>

          <View style={styles.detailsCard}>
            {verifiedData.photo_link && (
              <Image
                source={{
                  uri: `data:image/jpeg;base64,${verifiedData.photo_link}`,
                }}
                style={styles.photo}
              />
            )}

            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>Name:</Text>
              <Text style={styles.detailValue}>{verifiedData.name}</Text>
            </View>

            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>Date of Birth:</Text>
              <Text style={styles.detailValue}>{verifiedData.dob}</Text>
            </View>

            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>Gender:</Text>
              <Text style={styles.detailValue}>
                {verifiedData.gender === 'M' ? 'Male' : 'Female'}
              </Text>
            </View>

            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>Care Of:</Text>
              <Text style={styles.detailValue}>{verifiedData.care_of}</Text>
            </View>

            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>Address:</Text>
              <Text style={styles.detailValue}>{verifiedData.address}</Text>
            </View>

            {verifiedData.split_address && (
              <>
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>State:</Text>
                  <Text style={styles.detailValue}>
                    {verifiedData.split_address.state}
                  </Text>
                </View>
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>District:</Text>
                  <Text style={styles.detailValue}>
                    {verifiedData.split_address.dist}
                  </Text>
                </View>
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>Pincode:</Text>
                  <Text style={styles.detailValue}>
                    {verifiedData.split_address.pincode}
                  </Text>
                </View>
              </>
            )}
          </View>

          <TouchableOpacity style={styles.resetButton} onPress={handleReset}>
            <Text style={styles.resetButtonText}>Verify Another</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#F7F7F7' }}>
      <Headercomponent type={'2'} name={t('KYC Verification')} />

      <View style={styles.container}>
        {/* Icon & Heading */}
        <View style={styles.headerSection}>
          <Icon
            name="shield-check"
            size={60}
            color={AppStyle.container.backgroundColor}
          />
          <Text style={styles.heading}>Verify your identity</Text>
          <Text style={styles.description}>
            {!otpSent
              ? 'Please enter your Aadhaar number to receive OTP on your registered mobile number.'
              : 'Enter the 6-digit OTP sent to your registered mobile number.'}
          </Text>
        </View>

        {/* Aadhaar Input */}
        <TextInput
          style={[styles.input, otpSent && styles.inputDisabled]}
          placeholder="Enter 12-digit Aadhaar Number"
          placeholderTextColor="#999"
          keyboardType="numeric"
          maxLength={12}
          value={aadharNumber}
          onChangeText={setAadharNumber}
          editable={!otpSent}
        />

        {/* OTP Input - Show only after OTP is sent */}
        {otpSent && (
          <>
            <TextInput
              style={styles.input}
              placeholder="Enter 6-digit OTP"
              placeholderTextColor="#999"
              keyboardType="numeric"
              maxLength={6}
              value={otp}
              onChangeText={setOtp}
            />

            <TouchableOpacity onPress={handleSendOtp} disabled={loading}>
              <Text style={styles.resendText}>Resend OTP</Text>
            </TouchableOpacity>
          </>
        )}

        {/* Submit Button */}
        <TouchableOpacity
          style={[styles.submitButton, loading && styles.buttonDisabled]}
          onPress={otpSent ? handleVerifyOtp : handleSendOtp}
          disabled={loading}
        >
          <View style={styles.buttonContent}>
            {loading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.buttonText}>
                {otpSent ? 'Verify OTP' : 'Send OTP'}
              </Text>
            )}
          </View>
        </TouchableOpacity>

        {/* Cancel/Reset Button - Show after OTP is sent */}
        {otpSent && (
          <TouchableOpacity style={styles.cancelButton} onPress={handleReset}>
            <Text style={styles.cancelButtonText}>Cancel</Text>
          </TouchableOpacity>
        )}
      </View>
    </SafeAreaView>
  );
};

export default Kyc;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 24,
    paddingTop: 30,
  },
  headerSection: {
    alignItems: 'center',
    marginBottom: 30,
  },
  heading: {
    fontSize: 22,
    fontWeight: '700',
    color: '#2C2C54',
    marginTop: 12,
  },
  description: {
    textAlign: 'center',
    fontSize: 14,
    color: '#666',
    marginTop: 8,
    lineHeight: 20,
    paddingHorizontal: 10,
  },
  input: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 15,
    fontSize: 16,
    color: '#333',
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  inputDisabled: {
    backgroundColor: '#F5F5F5',
    color: '#999',
  },
  submitButton: {
    backgroundColor: AppStyle.container.backgroundColor,
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 10,
    flexDirection: 'row',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 4,
    elevation: 5,
  },
  buttonDisabled: {
    opacity: 0.6,
  },
  buttonContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  buttonText: {
    fontSize: 16,
    color: '#fff',
    fontWeight: '600',
  },
  resendText: {
    textAlign: 'center',
    color: AppStyle.container.backgroundColor,
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 10,
  },
  cancelButton: {
    marginTop: 15,
    paddingVertical: 14,
    alignItems: 'center',
  },
  cancelButtonText: {
    fontSize: 16,
    color: '#666',
    fontWeight: '600',
  },
  successSection: {
    alignItems: 'center',
    marginBottom: 30,
  },
  successTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: '#4CAF50',
    marginTop: 16,
  },
  detailsCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 20,
    marginBottom: 20,
    elevation: 2,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 4,
    shadowOffset: { width: 0, height: 2 },
  },
  photo: {
    width: 120,
    height: 120,
    borderRadius: 60,
    alignSelf: 'center',
    marginBottom: 20,
  },
  detailRow: {
    flexDirection: 'row',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  detailLabel: {
    fontSize: 14,
    color: '#666',
    fontWeight: '500',
    flex: 1,
  },
  detailValue: {
    fontSize: 14,
    color: '#333',
    fontWeight: '600',
    flex: 2,
  },
  resetButton: {
    backgroundColor: AppStyle.container.backgroundColor,
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  resetButtonText: {
    fontSize: 16,
    color: '#fff',
    fontWeight: '600',
  },
});
