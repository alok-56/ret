import React, { useState } from 'react';
import {
  SafeAreaView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { Headercomponent } from '../../../Components';
import { useTranslation } from 'react-i18next';
import { AppStyle } from '../../../config/Style';
import { NavMenu } from '../../../config/GlobalVariable';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

const LoyalityProfile = (props: any) => {
  const { navigation } = props;
  const { t } = useTranslation();

  const [holderName, setHolderName] = useState('Alok Kumar');
  const [bankName, setBankName] = useState('');
  const [branchName, setBranchName] = useState('');
  const [accountNo, setAccountNo] = useState('');
  const [ifscCode, setIfscCode] = useState('');

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#F9F9F9' }}>
      <Headercomponent type={'2'} name={t('Profile')} />

      <View style={styles.container}>
        {/* Profile Avatar and Name */}
        <View style={styles.profileSection}>
          <View style={styles.avatar}>
            <Icon name="account-circle" size={100} color="#ccc" />
          </View>
          <Text style={styles.userName}>Alok kumar</Text>

          <View style={styles.buttonRow}>
            <TouchableOpacity
              style={styles.actionButton}
              onPress={() => navigation.navigate(NavMenu.Scheme.Kyc)}
            >
              <Text style={styles.buttonText}>Complete KYC</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.actionButton}
              onPress={() => navigation.navigate(NavMenu.profile)}
            >
              <Text style={styles.buttonText}>Profile details</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Bank Details Form */}
        <View style={styles.formContainer}>
          <FormRow
            label="Holder Name"
            value={holderName}
            onChange={setHolderName}
          />
          <FormRow label="Bank Name" value={bankName} onChange={setBankName} />
          <FormRow
            label="Branch Name"
            value={branchName}
            onChange={setBranchName}
          />
          <FormRow
            label="Account No."
            value={accountNo}
            onChange={setAccountNo}
            keyboardType="numeric"
          />
          <FormRow label="IFSC Code" value={ifscCode} onChange={setIfscCode} />
        </View>

        {/* Submit Button */}
        <View style={styles.submitSection}>
          <TouchableOpacity
            style={styles.submitButton}
            onPress={() => navigation.navigate(NavMenu.updateBankDetails)}
          >
            <Icon
              name="bank"
              size={20}
              color="#fff"
              style={{ marginRight: 8 }}
            />
            <Text style={styles.submitText}>Update Bank Details</Text>
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
};

// Reusable Form Row Component
const FormRow = ({ label, value, onChange, keyboardType = 'default' }) => (
  <View style={styles.formRow}>
    <Text style={styles.label}>{label}</Text>
    <TextInput
      style={styles.input}
      value={value}
      onChangeText={onChange}
      placeholder={`Enter ${label}`}
      placeholderTextColor="#999"
      editable={false}
    />
  </View>
);

export default LoyalityProfile;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 20,
  },
  profileSection: {
    alignItems: 'center',
    marginTop: 20,
  },
  avatar: {
    borderRadius: 50,
    overflow: 'hidden',
    marginBottom: 10,
  },
  userName: {
    fontSize: 20,
    fontWeight: '600',
    color: '#2C2C54',
    marginBottom: 20,
  },
  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '80%',
  },
  actionButton: {
    backgroundColor: AppStyle.container.backgroundColor,
    borderRadius: 10,
    paddingVertical: 10,
    paddingHorizontal: 20,
    marginHorizontal: 5,
  },
  buttonText: {
    color: '#fff',
    fontWeight: '600',
    fontSize: 14,
  },
  formContainer: {
    backgroundColor: '#fff',
    borderRadius: 15,
    marginTop: 30,
    paddingVertical: 10,
    paddingHorizontal: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 5,
    elevation: 3,
  },
  formRow: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: '#EFEFEF',
    alignItems: 'center',
  },
  label: {
    flex: 0.4,
    fontSize: 16,
    fontWeight: '500',
    color: '#333',
    padding: 12,
    borderRightWidth: 1,
    borderRightColor: '#E0E0E0',
  },
  input: {
    flex: 0.6,
    padding: 12,
    fontSize: 16,
    color: '#333',
  },
  submitSection: {
    alignItems: 'center',
    marginTop: 30,
  },
  submitButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: AppStyle.container.backgroundColor,
    paddingVertical: 14,
    paddingHorizontal: 24,
    borderRadius: 12,
    elevation: 4,
  },
  submitText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
});
