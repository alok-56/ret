import React, { useState, useCallback, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  RefreshControl,
  Animated,
} from 'react-native';
import DatePicker from 'react-native-date-picker';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { Headercomponent } from '../../../Components';
import { useTranslation } from 'react-i18next';
import { SafeAreaView } from 'react-native-safe-area-context';

import { shallowEqual, useSelector } from 'react-redux';
import { GetScansummary } from '../../../ApiServices/httpServices';

// Skeleton Loader Component
const SkeletonLoader = () => {
  const [fadeAnim] = useState(new Animated.Value(0.3));

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(fadeAnim, {
          toValue: 1,
          duration: 800,
          useNativeDriver: true,
        }),
        Animated.timing(fadeAnim, {
          toValue: 0.3,
          duration: 800,
          useNativeDriver: true,
        }),
      ]),
    ).start();
  }, [fadeAnim]);

  const SkeletonCard = () => (
    <View style={styles.skeletonCard}>
      <Animated.View style={[styles.skeletonRow, { opacity: fadeAnim }]}>
        <View style={styles.skeletonLabel} />
        <View style={styles.skeletonValue} />
      </Animated.View>
      <Animated.View style={[styles.skeletonRow, { opacity: fadeAnim }]}>
        <View style={styles.skeletonLabel} />
        <View style={styles.skeletonValue} />
      </Animated.View>
      <Animated.View style={[styles.skeletonRow, { opacity: fadeAnim }]}>
        <View style={styles.skeletonLabel} />
        <View style={styles.skeletonValue} />
      </Animated.View>
      <Animated.View style={[styles.skeletonRow, { opacity: fadeAnim }]}>
        <View style={styles.skeletonLabel} />
        <View style={styles.skeletonValueLong} />
      </Animated.View>
      <Animated.View style={[styles.skeletonRow, { opacity: fadeAnim }]}>
        <View style={styles.skeletonLabel} />
        <View style={styles.skeletonValueLong} />
      </Animated.View>
    </View>
  );

  return (
    <View style={styles.skeletonContainer}>
      <SkeletonCard />
      <SkeletonCard />
      <SkeletonCard />
    </View>
  );
};

const InfoRow = ({ label, value, isLast }: any) => (
  <View style={[styles.row, !isLast && styles.rowWithBorder]}>
    <Text style={styles.label}>{label}</Text>
    <Text style={styles.value}>{value}</Text>
  </View>
);

const AccumulateReport = () => {
  const { t } = useTranslation();
  const [startDate, setStartDate] = useState(new Date('2025-10-01'));
  const [endDate, setEndDate] = useState(new Date('2025-10-10'));
  const [showStartPicker, setShowStartPicker] = useState(false);
  const [showEndPicker, setShowEndPicker] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [loading, setLoading] = useState(true);
  const [scanDataList, setScanDataList] = useState([]);

  const profileDetail = useSelector(
    (state: any) => state.auth.profileData,
    shallowEqual,
  );

  // Fetch scan data from API
  const fetchScanData = async () => {
    setLoading(true);
    try {
      const response: any = await GetScansummary(profileDetail.retailerCode);

      if (response.status && response.data) {
        setScanDataList(response.data);
      } else {
        setScanDataList([]);
      }
    } catch (error) {
      console.error('Error fetching scan data:', error);
      setScanDataList([]);
    } finally {
      setLoading(false);
    }
  };

  // Initial data fetch
  useEffect(() => {
    fetchScanData();
  }, []);

  const formatDisplayDate = (date: Date): string => {
    const options: any = { month: 'short', day: 'numeric', year: 'numeric' };
    return date.toLocaleDateString('en-US', options);
  };

  const formatDate = (dateString: string): string => {
    const date = new Date(dateString);
    return date.toISOString().split('T')[0];
  };

  const formatTime = (dateString: string): string => {
    const date = new Date(dateString);
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    });
  };

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    fetchScanData().finally(() => {
      setRefreshing(false);
    });
  }, []);

  // Filter data based on date range
  const filteredData = scanDataList.filter((item: any) => {
    const itemDate = new Date(item.createdAt);
    return itemDate >= startDate && itemDate <= endDate;
  });

  const totalPoints = filteredData.reduce(
    (sum: number, item: any) => sum + item.points,
    0,
  );

  const renderItem = ({ item, index }: any) => (
    <View style={styles.card}>
      <View style={styles.cardHeader}>
        <View style={styles.pointsBadge}>
          <Text style={styles.pointsBadgeText}>{item.points}</Text>
          <Text style={styles.pointsLabel}>pts</Text>
        </View>
        <View
          style={[
            styles.statusBadge,
            item.status === 1 ? styles.statusCompleted : styles.statusPending,
          ]}
        >
          <Text
            style={[
              styles.statusText,
              item.status === 0 && styles.statusTextPending,
            ]}
          >
            {item.status === 1 ? 'Completed' : 'Pending'}
          </Text>
        </View>
      </View>
      <View style={styles.divider} />
      <InfoRow label="Date" value={formatDate(item.createdAt)} isLast={false} />
      <InfoRow label="Time" value={formatTime(item.createdAt)} isLast={false} />
      <InfoRow
        label="Product Code"
        value={item.productCodeValue}
        isLast={false}
      />
      <InfoRow label="Product Name" value={item.productName} isLast={true} />
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <Headercomponent type={'2'} name={t('Scanned History')} />

      {/* Date Range Filter */}
      <View style={styles.dateRangeContainer}>
        <View style={styles.dateCard}>
          <Text style={styles.dateCardLabel}>Start Date</Text>
          <TouchableOpacity
            onPress={() => setShowStartPicker(true)}
            style={styles.dateButton}
          >
            <Icon name="event" size={20} color="#1976D2" />
            <Text style={styles.dateButtonText}>
              {formatDisplayDate(startDate)}
            </Text>
          </TouchableOpacity>
        </View>

        <View style={styles.dateArrow}>
          <Icon name="arrow-forward" size={24} color="#999" />
        </View>

        <View style={styles.dateCard}>
          <Text style={styles.dateCardLabel}>End Date</Text>
          <TouchableOpacity
            onPress={() => setShowEndPicker(true)}
            style={styles.dateButton}
          >
            <Icon name="event" size={20} color="#1976D2" />
            <Text style={styles.dateButtonText}>
              {formatDisplayDate(endDate)}
            </Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Date Pickers */}
      <DatePicker
        modal
        open={showStartPicker}
        date={startDate}
        mode="date"
        onConfirm={date => {
          setShowStartPicker(false);
          setStartDate(date);
        }}
        onCancel={() => setShowStartPicker(false)}
        maximumDate={endDate}
      />

      <DatePicker
        modal
        open={showEndPicker}
        date={endDate}
        mode="date"
        onConfirm={date => {
          setShowEndPicker(false);
          setEndDate(date);
        }}
        onCancel={() => setShowEndPicker(false)}
        minimumDate={startDate}
        maximumDate={new Date()}
      />

      {/* Total Summary Card */}
      <View style={styles.summaryCard}>
        <View style={styles.summaryContent}>
          <Icon name="qr-code-scanner" size={32} color="#1976D2" />
          <View style={styles.summaryTextContainer}>
            <Text style={styles.summaryLabel}>Total Points Scanned</Text>
            <Text style={styles.summaryValue}>{totalPoints} pts</Text>
          </View>
        </View>
        <View style={styles.summaryBadge}>
          <Text style={styles.summaryBadgeText}>
            {filteredData.length} scans
          </Text>
        </View>
      </View>

      {/* Data List with Skeleton */}
      {loading ? (
        <SkeletonLoader />
      ) : (
        <FlatList
          data={filteredData}
          keyExtractor={(item: any, index) =>
            (item.productCodeValue || `scan-${index}`) + index
          }
          renderItem={renderItem}
          contentContainerStyle={styles.listContent}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
          }
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <Icon name="inbox" size={64} color="#ccc" />
              <Text style={styles.noDataText}>No scans found</Text>
              <Text style={styles.noDataSubtext}>
                Try adjusting your date range
              </Text>
            </View>
          }
          showsVerticalScrollIndicator={false}
        />
      )}
    </SafeAreaView>
  );
};

export default AccumulateReport;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f7fa',
  },
  dateRangeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: 20,
    marginTop: 15,
    marginBottom: 10,
  },
  dateCard: {
    flex: 1,
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 4,
    shadowOffset: { width: 0, height: 2 },
  },
  dateCardLabel: {
    fontSize: 12,
    color: '#666',
    marginBottom: 8,
    fontWeight: '500',
  },
  dateButton: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  dateButtonText: {
    marginLeft: 8,
    fontSize: 14,
    color: '#222',
    fontWeight: '600',
  },
  dateArrow: {
    marginHorizontal: 8,
  },
  summaryCard: {
    backgroundColor: '#fff',
    marginHorizontal: 20,
    marginVertical: 10,
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    elevation: 3,
    shadowColor: '#000',
    shadowOpacity: 0.08,
    shadowRadius: 4,
    shadowOffset: { width: 0, height: 2 },
  },
  summaryContent: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  summaryTextContainer: {
    marginLeft: 12,
  },
  summaryLabel: {
    fontSize: 13,
    color: '#666',
    marginBottom: 4,
  },
  summaryValue: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#1976D2',
  },
  summaryBadge: {
    backgroundColor: '#E3F2FD',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  summaryBadgeText: {
    fontSize: 12,
    color: '#1976D2',
    fontWeight: '600',
  },
  listContent: {
    paddingHorizontal: 20,
    paddingTop: 5,
    paddingBottom: 40,
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 3,
    shadowOffset: { width: 0, height: 1 },
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  pointsBadge: {
    flexDirection: 'row',
    alignItems: 'baseline',
  },
  pointsBadgeText: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#1976D2',
  },
  pointsLabel: {
    fontSize: 14,
    color: '#1976D2',
    marginLeft: 4,
    fontWeight: '600',
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  statusCompleted: {
    backgroundColor: '#E8F5E9',
  },
  statusPending: {
    backgroundColor: '#FFF3E0',
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#2E7D32',
  },
  statusTextPending: {
    color: '#F57C00',
  },
  divider: {
    height: 1,
    backgroundColor: '#f0f0f0',
    marginBottom: 12,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 8,
  },
  rowWithBorder: {
    borderBottomWidth: 1,
    borderBottomColor: '#f5f5f5',
  },
  label: {
    fontSize: 14,
    color: '#666',
    flex: 1,
  },
  value: {
    fontSize: 14,
    fontWeight: '600',
    color: '#222',
    flex: 1,
    textAlign: 'right',
  },
  emptyContainer: {
    alignItems: 'center',
    marginTop: 60,
  },
  noDataText: {
    textAlign: 'center',
    color: '#999',
    marginTop: 16,
    fontSize: 16,
    fontWeight: '500',
  },
  noDataSubtext: {
    textAlign: 'center',
    color: '#bbb',
    marginTop: 6,
    fontSize: 14,
  },
  // Skeleton Loader Styles
  skeletonContainer: {
    paddingHorizontal: 20,
    paddingTop: 5,
  },
  skeletonCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 3,
    shadowOffset: { width: 0, height: 1 },
  },
  skeletonRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  skeletonLabel: {
    width: '30%',
    height: 14,
    backgroundColor: '#e0e0e0',
    borderRadius: 4,
  },
  skeletonValue: {
    width: '25%',
    height: 14,
    backgroundColor: '#e0e0e0',
    borderRadius: 4,
  },
  skeletonValueLong: {
    width: '40%',
    height: 14,
    backgroundColor: '#e0e0e0',
    borderRadius: 4,
  },
});
