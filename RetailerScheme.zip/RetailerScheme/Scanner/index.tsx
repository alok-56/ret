import React, { useEffect, useState, useRef, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Animated,
  Dimensions,
  Alert,
  ActivityIndicator,
  TouchableOpacity,
} from 'react-native';
import {
  Camera,
  useCameraDevices,
  useCodeScanner,
} from 'react-native-vision-camera';
import type { Code } from 'react-native-vision-camera';
import { shallowEqual, useSelector } from 'react-redux';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Headercomponent } from '../../../Components';
import { useTranslation } from 'react-i18next';
import AntDesign from 'react-native-vector-icons/AntDesign';
import { getLocation } from '../../../config/GlobalVariable';
import { ScanQr } from '../../../ApiServices/httpServices';

const { width, height } = Dimensions.get('window');
const SCAN_AREA_SIZE = 250;

const ScannerScreen = (props: any) => {
  const { t } = useTranslation();
  const [hasPermission, setHasPermission] = useState(false);
  const [totalPoints, setTotalPoints] = useState(0);
  const [isScanning, setIsScanning] = useState(false);
  const [scannedCodes, setScannedCodes] = useState<string[]>([]);

  const devices = useCameraDevices();
  const device = devices.find(({ position }) => position === 'back');
  const animation = useRef(new Animated.Value(0)).current;

  const profileDetail: any = useSelector(
    (state: any) => state.auth.profileData,
    shallowEqual,
  );

  // Submit scanned QR code to API
  const submitQRCode = async (qrCode: string) => {
    if (scannedCodes.includes(qrCode)) {
      Alert.alert('Already Scanned', 'This QR code has already been scanned.');
      return;
    }

    try {
      setIsScanning(true);
      // Get current location
      const currentLocation = await getLocation();

      const params = {
        Qrcode: qrCode,
        Retailercode: profileDetail?.retailerCode,
        Lat: currentLocation?.latitude ? String(currentLocation?.latitude) : '',
        Long: currentLocation?.longitude
          ? String(currentLocation?.longitude)
          : '',
      };

      // Make API call
      const result = await ScanQr(params);

      if (result.status) {
        // Success - add to scanned codes
        setScannedCodes(prev => [...prev, qrCode]);
        setTotalPoints(prev => prev + 1);

        Alert.alert(
          'Success! 🎉',
          result.message || 'QR code scanned successfully',
          [{ text: 'OK' }],
        );
      } else {
        Alert.alert('Error', result.message || 'Failed to scan QR code');
      }
    } catch (error) {
      console.error('QR Scan Error:', error);
      Alert.alert('Error', 'Failed to process QR code. Please try again.');
    } finally {
      setIsScanning(false);
    }
  };

  const onCodeScanned = useCallback(
    (codes: Code[]) => {
      if (isScanning) return;

      const value = codes[0]?.value;
      if (value) {
        submitQRCode(value);
      }
    },
    [isScanning, scannedCodes],
  );

  const codeScanner = useCodeScanner({
    codeTypes: ['qr', 'ean-13'],
    onCodeScanned,
  });

  useEffect(() => {
    const getPermission = async () => {
      const status = await Camera.requestCameraPermission();
      setHasPermission(status === 'granted');
    };
    getPermission();
  }, []);

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(animation, {
          toValue: SCAN_AREA_SIZE,
          duration: 2000,
          useNativeDriver: true,
        }),
        Animated.timing(animation, {
          toValue: 0,
          duration: 2000,
          useNativeDriver: true,
        }),
      ]),
    ).start();
  }, [animation]);

  if (!hasPermission) {
    return (
      <SafeAreaView style={styles.container}>
        <Headercomponent
          type={'1'}
          name={t('Scan QR Code')}
          onPress={() => props.navigation.goBack()}
        />
        <View style={styles.centered}>
          <Text style={styles.permissionText}>
            Camera permission is required to scan QR codes
          </Text>
        </View>
      </SafeAreaView>
    );
  }

  if (device == null) {
    return (
      <SafeAreaView style={styles.container}>
        <Headercomponent
          type={'1'}
          name={t('Scan QR Code')}
          onPress={() => props.navigation.goBack()}
        />
        <View style={styles.centered}>
          <ActivityIndicator size="large" color="#6B46C1" />
          <Text style={styles.loadingText}>Loading camera...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <View style={styles.container}>
      <Camera
        style={StyleSheet.absoluteFill}
        device={device}
        isActive={!isScanning}
        codeScanner={codeScanner}
      />

      {/* Loading Overlay */}
      {isScanning && (
        <View style={styles.loadingOverlay}>
          <View style={styles.loadingCard}>
            <ActivityIndicator size="large" color="#6B46C1" />
            <Text style={styles.loadingOverlayText}>Processing QR Code...</Text>
          </View>
        </View>
      )}

      {/* Header Card */}
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => props.navigation.goBack()}
        >
          <AntDesign name="arrowleft" size={24} color="#1a1a1a" />
        </TouchableOpacity>
        <View style={styles.headerContent}>
          <Text style={styles.emoji}>🎯</Text>
          <Text style={styles.headerText}>
            Scan QR codes from outside the box To Earn Points
          </Text>
        </View>
      </View>

      {/* Overlay */}
      <View style={styles.overlay}>
        <View style={styles.maskTop} />
        <View style={styles.maskCenter}>
          <View style={styles.maskSide} />
          <View style={styles.scanBox}>
            {/* Corner Borders */}
            <View style={styles.cornerTopLeft} />
            <View style={styles.cornerTopRight} />
            <View style={styles.cornerBottomLeft} />
            <View style={styles.cornerBottomRight} />

            {/* Scanning line */}
            <Animated.View
              style={[
                styles.scanLine,
                {
                  transform: [{ translateY: animation }],
                },
              ]}
            />
          </View>
          <View style={styles.maskSide} />
        </View>
        <View style={styles.maskBottom}>
          <Text style={styles.instructionText}>Align QR code within frame</Text>
        </View>
      </View>

      {/* Footer */}
      <View style={styles.footer}>
        <Text style={styles.title}>Scan QR Code</Text>
        <Text style={styles.subtitle}>
          Point your camera at the QR codes on your product box
        </Text>
        <View style={styles.rewardBox}>
          <Text style={styles.rewardIcon}>🎁</Text>
          <Text style={styles.rewardText}>
            Total reward points :{' '}
            <Text style={styles.points}>{totalPoints}</Text>
          </Text>
        </View>

        {scannedCodes.length > 0 && (
          <View style={styles.scannedInfo}>
            <Text style={styles.scannedText}>
              Scanned: {scannedCodes.length} QR code(s)
            </Text>
          </View>
        )}
      </View>
    </View>
  );
};

export default ScannerScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  centered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  permissionText: {
    fontSize: 16,
    textAlign: 'center',
    color: '#333',
  },
  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: '#666',
  },
  overlay: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
  },
  maskTop: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
  },
  maskCenter: {
    flexDirection: 'row',
  },
  maskSide: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
  },
  scanBox: {
    width: SCAN_AREA_SIZE,
    height: SCAN_AREA_SIZE,
    position: 'relative',
    overflow: 'hidden',
  },
  cornerTopLeft: {
    position: 'absolute',
    top: 0,
    left: 0,
    width: 40,
    height: 40,
    borderTopWidth: 4,
    borderLeftWidth: 4,
    borderColor: '#00FF00',
  },
  cornerTopRight: {
    position: 'absolute',
    top: 0,
    right: 0,
    width: 40,
    height: 40,
    borderTopWidth: 4,
    borderRightWidth: 4,
    borderColor: '#00FF00',
  },
  cornerBottomLeft: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    width: 40,
    height: 40,
    borderBottomWidth: 4,
    borderLeftWidth: 4,
    borderColor: '#00FF00',
  },
  cornerBottomRight: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 40,
    height: 40,
    borderBottomWidth: 4,
    borderRightWidth: 4,
    borderColor: '#00FF00',
  },
  maskBottom: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    alignItems: 'center',
    paddingTop: 20,
  },
  instructionText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  scanLine: {
    position: 'absolute',
    width: '100%',
    height: 2,
    backgroundColor: '#00FF00',
    shadowColor: '#00FF00',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 4,
  },
  header: {
    position: 'absolute',
    top: 40,
    left: 20,
    right: 20,
    backgroundColor: 'rgba(255,255,255,0.95)',
    borderRadius: 20,
    padding: 16,
    zIndex: 10,
    elevation: 5,
  },
  backButton: {
    position: 'absolute',
    top: 16,
    left: 16,
    zIndex: 11,
  },
  headerContent: {
    alignItems: 'center',
    marginLeft: 30,
  },
  emoji: {
    fontSize: 36,
    marginBottom: 6,
  },
  headerText: {
    fontSize: 15,
    fontWeight: '600',
    textAlign: 'center',
    color: '#1a1a1a',
  },
  footer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: '#fff',
    borderTopLeftRadius: 32,
    borderTopRightRadius: 32,
    padding: 24,
    paddingBottom: 40,
    elevation: 10,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: '#1a1a1a',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 14,
    color: '#6b7280',
    marginBottom: 20,
  },
  rewardBox: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    backgroundColor: '#f3f4f6',
    borderRadius: 12,
  },
  rewardIcon: {
    fontSize: 28,
    marginRight: 8,
  },
  rewardText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#6B46C1',
  },
  points: {
    color: '#6B46C1',
    fontSize: 20,
    fontWeight: '700',
  },
  scannedInfo: {
    marginTop: 12,
    alignItems: 'center',
  },
  scannedText: {
    fontSize: 13,
    color: '#059669',
    fontWeight: '500',
  },
  loadingOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.7)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 999,
  },
  loadingCard: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 24,
    alignItems: 'center',
    elevation: 5,
  },
  loadingOverlayText: {
    marginTop: 12,
    fontSize: 16,
    fontWeight: '600',
    color: '#1a1a1a',
  },
});
