import React, { useEffect, useState } from 'react';
import { Text, View, StyleSheet, TouchableOpacity, ActivityIndicator } from 'react-native';
import { Headercomponent } from '../../../Components';
import { useTranslation } from 'react-i18next';
import { AppStyle } from '../../../config/Style';
import Refresh from 'react-native-vector-icons/EvilIcons';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import { NavMenu } from '../../../config/GlobalVariable';
import { SafeAreaView } from 'react-native-safe-area-context';
import { GetDashboard } from '../../../ApiServices/httpServices';
import { shallowEqual, useSelector } from 'react-redux';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';

// Define proper types
interface DashboardData {
  availableamount?: number;
  retainedamount?: number;
  totalcoiledscaned?: number;
  totalearned?: number;
  totalscanedamount?: number;
}

interface ProfileDetail {
  retailerCode: string;
}

interface RootState {
  auth: {
    profileData: ProfileDetail;
  };
}

interface DashboardProps {
  navigation: NativeStackNavigationProp<any>;
}

const Dashboard: React.FC<DashboardProps> = ({ navigation }) => {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(false);
  const { t } = useTranslation();

  const profileDetail = useSelector(
    (state: RootState) => state.auth.profileData,
    shallowEqual,
  );

  useEffect(() => {
    GetDashboardData();
  }, []);

  const GetDashboardData = async () => {
    setLoading(true);
    try {
      const res = await GetDashboard(profileDetail.retailerCode);
      if (res.status && res?.data && res.data.length > 0) {
        setData(res.data[0]);
      } else {
        setData(null);
      }
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
      setData(null);
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = () => {
    GetDashboardData();
  };

  return (
    <SafeAreaView style={styles.container}>
      <Headercomponent type={'2'} name={t('Retailer Loyality Programs')} />

      <View style={styles.cardRow}>
        <TouchableOpacity
          onPress={() => navigation.navigate(NavMenu.Scheme.Scanner)}
          style={styles.card}
        >
          <View style={styles.cardContent}>
            <MaterialIcons name="qr-code-scanner" size={24} color="#000" />
            <Text style={styles.cardText}>Scan</Text>
          </View>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.card}
          onPress={() => navigation.navigate(NavMenu.Scheme.Redeem)}
        >
          <View style={styles.cardContent}>
            <MaterialIcons name="redeem" size={24} color="#000" />
            <Text style={styles.cardText}>Redeem</Text>
          </View>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.card}
          onPress={() => navigation.navigate(NavMenu.Scheme.Profile)}
        >
          <View style={styles.cardContent}>
            <MaterialIcons name="person" size={24} color="#000" />
            <Text style={styles.cardText}>Profile</Text>
          </View>
        </TouchableOpacity>
      </View>

      <View style={styles.balanceWrapper}>
        <View style={styles.balanceCard}>
          <TouchableOpacity 
            style={styles.refreshIconWrapper}
            onPress={handleRefresh}
            disabled={loading}
          >
            <Refresh name="refresh" size={24} color="#000" />
          </TouchableOpacity>

          <View style={styles.infoRow}>
            <Text style={styles.infoText}>03 July 2025</Text>
            <Text style={styles.infoText}>Total Balance</Text>
          </View>

          <View style={styles.infoRow}>
            <Text style={styles.infoText}>10:30 A.M</Text>
            <Text style={styles.balanceAmount}>
              {loading ? '...' : (data?.availableamount ?? 0)}
            </Text>
          </View>

          <View style={styles.footerBalance}>
            <View style={styles.footerRow}>
              <Text style={styles.footerLabel}>RETAINED</Text>
              <Text style={styles.footerValue}>
                {loading ? '...' : (data?.retainedamount ?? 0)}
              </Text>
            </View>
          </View>
        </View>
      </View>

      <View style={styles.wrapper}>
        <View style={styles.cardContainer}>
          <Text style={styles.title}>Performance Report</Text>

          {loading ? (
            <View style={styles.loadingContainer}>
              <ActivityIndicator size="large" color={AppStyle.container.backgroundColor} />
            </View>
          ) : (
            <>
              {/* Row 1 */}
              <View style={styles.row}>
                <View style={styles.metricCard}>
                  <View style={styles.metricContent}>
                    <Text style={styles.metricTitle}>Total Coil Scanned</Text>
                    <Text style={styles.metricValue}>
                      {data?.totalcoiledscaned ?? 0}
                    </Text>
                    <Text style={styles.metricUnit}>boxes</Text>
                  </View>
                </View>

                <View style={styles.metricCard}>
                  <View style={styles.metricContent}>
                    <Text style={styles.metricTitle}>Total Earned</Text>
                    <Text style={styles.metricValue}>
                      {data?.totalearned ?? 0}
                    </Text>
                    <Text style={styles.metricUnit}>Points</Text>
                  </View>
                </View>
              </View>

              {/* Row 2 */}
              <View style={styles.row}>
                <View style={styles.metricCard}>
                  <View style={styles.metricContent}>
                    <Text style={styles.metricTitle}>Scanning History</Text>
                    <Text style={styles.metricValue}>
                      {data?.totalscanedamount ?? 0}
                    </Text>
                    <Text style={styles.metricUnit}>Points</Text>
                    <TouchableOpacity
                      onPress={() =>
                        navigation.navigate(NavMenu.Scheme.AcculateReport)
                      }
                    >
                      <Text style={styles.viewStatement}>View Statement</Text>
                    </TouchableOpacity>
                  </View>
                </View>

                <View style={styles.metricCard}>
                  <View style={styles.metricContent}>
                    <Text style={styles.metricTitle}>Earning History</Text>
                    <Text style={styles.metricValue}>
                      {data?.totalearned ?? 0}
                    </Text>
                    <Text style={styles.metricUnit}>Points</Text>
                    <TouchableOpacity
                      onPress={() =>
                        navigation.navigate(NavMenu.Scheme.RedeemReport)
                      }
                    >
                      <Text style={styles.viewStatement}>View Statement</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </View>
            </>
          )}
        </View>
      </View>
    </SafeAreaView>
  );
};

export default Dashboard;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  cardRow: {
    width: '95%',
    alignSelf: 'center',
    marginTop: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  card: {
    width: '32%',
    height: 80,
    backgroundColor: '#e0e0e0',
    borderRadius: 10,
  },
  cardContent: {
    justifyContent: 'center',
    alignItems: 'center',
    flex: 1,
  },
  cardText: {
    marginTop: 2,
    fontSize: 14,
    fontWeight: '400',
  },
  balanceWrapper: {
    width: '95%',
    alignSelf: 'center',
  },
  balanceCard: {
    width: '100%',
    height: 135,
    borderRadius: 10,
    backgroundColor: '#fff',
    marginTop: 20,
    elevation: 2,
    paddingTop: 10,
  },
  refreshIconWrapper: {
    width: '95%',
    alignSelf: 'center',
    alignItems: 'flex-end',
  },
  infoRow: {
    width: '95%',
    justifyContent: 'space-between',
    flexDirection: 'row',
    alignSelf: 'center',
  },
  infoText: {
    fontSize: 14,
    fontWeight: '400',
  },
  balanceAmount: {
    fontSize: 16,
    fontWeight: '500',
  },
  footerBalance: {
    width: '100%',
    height: 50,
    backgroundColor: AppStyle.container.backgroundColor,
    borderRadius: 8,
    position: 'absolute',
    bottom: 0,
    justifyContent: 'center',
  },
  footerRow: {
    width: '95%',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignSelf: 'center',
  },
  footerLabel: {
    fontSize: 16,
    fontWeight: '500',
    color: '#fff',
  },
  footerValue: {
    fontSize: 16,
    fontWeight: '600',
    color: '#f3f1f0ff',
  },
  wrapper: {
    width: '95%',
    alignSelf: 'center',
    marginTop: 20,
  },
  cardContainer: {
    width: '100%',
    height: 350,
    backgroundColor: '#fff',
    borderRadius: 10,
    elevation: 2,
    padding: 15,
  },
  title: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 10,
    color: '#333',
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 15,
  },
  metricCard: {
    width: '48%',
    backgroundColor: '#f5f5f5',
    borderRadius: 10,
    paddingVertical: 15,
    paddingHorizontal: 10,
  },
  metricContent: {
    alignItems: 'center',
  },
  metricTitle: {
    fontSize: 14,
    fontWeight: '500',
    marginBottom: 5,
    color: '#333',
    textAlign: 'center',
  },
  metricValue: {
    fontSize: 18,
    fontWeight: '700',
    color: '#000',
  },
  metricUnit: {
    fontSize: 13,
    color: '#666',
    marginBottom: 8,
  },
  viewStatement: {
    fontSize: 13,
    color: '#1976D2',
    fontWeight: '500',
    textDecorationLine: 'underline',
    marginTop: 5,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});