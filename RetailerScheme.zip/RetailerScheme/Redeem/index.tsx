import React, { useState, useEffect } from 'react';
import {
  SafeAreaView,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { Headercomponent } from '../../../Components';
import { useTranslation } from 'react-i18next';
import { AppStyle } from '../../../config/Style';
import { shallowEqual, useSelector } from 'react-redux';
import { getLocation } from '../../../config/GlobalVariable';
import { ReedemPoints, GetBankingstatus, GetDashboard } from '../../../ApiServices/httpServices';

const Redeem = (props: any) => {
  const { t } = useTranslation();
  const [points, setPoints] = useState('');
  const [holderName, setHolderName] = useState('');
  const [bankName, setBankName] = useState('');
  const [branchName, setBranchName] = useState('');
  const [accountNo, setAccountNo] = useState('');
  const [ifscCode, setIfscCode] = useState('');
  const [isRedeeming, setIsRedeeming] = useState(false);
  const [isLoadingBankDetails, setIsLoadingBankDetails] = useState(true);
  const [isLoadingDashboard, setIsLoadingDashboard] = useState(true);
  const [bankingDetails, setBankingDetails] = useState<any>(null);
  const [dashboardData, setDashboardData] = useState<any>(null);
  const [canRedeem, setCanRedeem] = useState(false);

  const profileDetail: any = useSelector(
    (state: any) => state.auth.profileData,
    shallowEqual,
  );

  // Available points from dashboard API
  const availablePoints = dashboardData?.availableamount || 0;

  // Fetch banking details and dashboard data on component mount
  useEffect(() => {
    fetchBankingDetails();
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      setIsLoadingDashboard(true);
      const retailerCode = profileDetail?.retailerCode;

      if (!retailerCode) {
        console.error('Retailer code not found');
        setIsLoadingDashboard(false);
        return;
      }

      const result = await GetDashboard(retailerCode);

      if (result.status && result.data && result.data.length > 0) {
        setDashboardData(result.data[0]);
      } else {
        console.error('Failed to fetch dashboard data');
      }
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setIsLoadingDashboard(false);
    }
  };

  const fetchBankingDetails = async () => {
    try {
      setIsLoadingBankDetails(true);
      const retailerCode = profileDetail?.retailerCode;
      
      if (!retailerCode) {
        Alert.alert('Error', 'Retailer code not found');
        setIsLoadingBankDetails(false);
        return;
      }

      const result = await GetBankingstatus(retailerCode);

      if (result.status && result.data && result.data.length > 0) {
        const bankDetails = result.data[0];
        setBankingDetails(bankDetails);

        // Check if user can redeem (has all required fields)
        const hasRequiredFields = 
          bankDetails.benaficeryId &&
          bankDetails.accountholdername &&
          bankDetails.accountnumber &&
          bankDetails.ifscCode;

        setCanRedeem(hasRequiredFields);

        if (hasRequiredFields) {
          // Pre-fill the form with banking details
          setHolderName(bankDetails.accountholdername || '');
          setAccountNo(bankDetails.accountnumber || '');
          setIfscCode(bankDetails.ifscCode || '');
          setBankName(bankDetails.bankName || '');
        } else {
          Alert.alert(
            'Banking Details Required',
            'Please complete your banking details to redeem points. You need to add account holder name, account number, IFSC code, and beneficiary ID.',
            [{ text: 'OK' }]
          );
        }
      } else {
        Alert.alert(
          'No Banking Details',
          'Please add your banking details first to redeem points.',
          [{ text: 'OK' }]
        );
        setCanRedeem(false);
      }
    } catch (error) {
      console.error('Error fetching banking details:', error);
      Alert.alert('Error', 'Failed to fetch banking details. Please try again.');
      setCanRedeem(false);
    } finally {
      setIsLoadingBankDetails(false);
    }
  };

  const validateForm = () => {
    // First check if user has banking details
    if (!canRedeem) {
      Alert.alert(
        'Banking Details Required',
        'Please complete your banking details before redeeming points.',
      );
      return false;
    }

    if (!points || points === '0') {
      Alert.alert('Validation Error', 'Please enter points to redeem');
      return false;
    }

    const pointsNum = parseInt(points);
    if (isNaN(pointsNum) || pointsNum <= 0) {
      Alert.alert('Validation Error', 'Please enter valid points');
      return false;
    }

    if (pointsNum > availablePoints) {
      Alert.alert(
        'Validation Error',
        `You can only redeem up to ${availablePoints} points`,
      );
      return false;
    }

    return true;
  };

  const handleRedeem = async () => {
    if (!validateForm()) {
      return;
    }

    try {
      setIsRedeeming(true);

      // Get current location
      const currentLocation = await getLocation();

      const params = {
        Points: points,
        Retailercode: profileDetail?.retailerCode || '',
        ReedemAccType: 'Bank',
        Lat: currentLocation?.latitude ? String(currentLocation?.latitude) : '',
        Long: currentLocation?.longitude
          ? String(currentLocation?.longitude)
          : '',
        // Use banking details from fetched data
        BeneficiaryId: bankingDetails?.benaficeryId || '',
        HolderName: bankingDetails?.accountholdername || holderName.trim(),
        AccountNo: bankingDetails?.accountnumber || accountNo.trim(),
        IfscCode: bankingDetails?.ifscCode || ifscCode.toUpperCase().trim(),
        BankName: bankingDetails?.bankName || bankName.trim(),
        BranchName: branchName.trim() || '',
      };

      console.log('Redeeming points with params:', params);

      // Make API call
      const result = await ReedemPoints(params);

      if (result.status) {
        // Refresh dashboard data to get updated available points
        await fetchDashboardData();

        Alert.alert(
          'Success! 🎉',
          result.message || 'Points redeemed successfully',
          [
            {
              text: 'OK',
              onPress: () => {
                // Clear form
                setPoints('');

                // Navigate back or to another screen
                if (props.navigation) {
                  props.navigation.goBack();
                }
              },
            },
          ],
        );
      } else {
        Alert.alert('Error', result.message || 'Failed to redeem points');
      }
    } catch (error) {
      console.error('Redeem Error:', error);
      Alert.alert('Error', 'Failed to process redemption. Please try again.');
    } finally {
      setIsRedeeming(false);
    }
  };

  return (
    <SafeAreaView style={[styles.container]}>
      <Headercomponent
        type={'2'}
        name={t('Redeem Point')}
        onPress={() => props.navigation?.goBack()}
      />

      {(isLoadingBankDetails || isLoadingDashboard) ? (
        <View style={styles.centered}>
          <ActivityIndicator size="large" color="#6B46C1" />
          <Text style={styles.loadingText}>
            {isLoadingBankDetails
              ? 'Loading banking details...'
              : 'Loading dashboard...'}
          </Text>
        </View>
      ) : (
        <ScrollView contentContainerStyle={styles.scrollContent}>
          {/* Dashboard Stats Card */}
          {dashboardData && (
            <View style={styles.statsCard}>
              <View style={styles.statRow}>
                <View style={styles.statItem}>
                  <Text style={styles.statLabel}>Total Earned</Text>
                  <Text style={styles.statValue}>
                    ₹{dashboardData.totalearned || 0}
                  </Text>
                </View>
                <View style={styles.statItem}>
                  <Text style={styles.statLabel}>Available</Text>
                  <Text style={[styles.statValue, styles.availableValue]}>
                    ₹{dashboardData.availableamount || 0}
                  </Text>
                </View>
              </View>
              <View style={styles.statRow}>
                <View style={styles.statItem}>
                  <Text style={styles.statLabel}>Scanned Amount</Text>
                  <Text style={styles.statValue}>
                    ₹{dashboardData.totalscanedamount || 0}
                  </Text>
                </View>
                <View style={styles.statItem}>
                  <Text style={styles.statLabel}>Retained</Text>
                  <Text style={styles.statValue}>
                    ₹{dashboardData.retainedamount || 0}
                  </Text>
                </View>
              </View>
              <View style={styles.scanInfo}>
                <Text style={styles.scanText}>
                  🎯 Total Coils Scanned:{' '}
                  <Text style={styles.scanValue}>
                    {dashboardData.totalcoiledscaned || 0}
                  </Text>
                </Text>
              </View>
            </View>
          )}

          {/* Banking Status Banner */}
          {!canRedeem && (
            <View style={styles.warningBanner}>
              <Text style={styles.warningIcon}>⚠️</Text>
              <Text style={styles.warningText}>
                Please complete your banking details to redeem points
              </Text>
            </View>
          )}

          {canRedeem && bankingDetails?.isbenverified && (
            <View style={styles.successBanner}>
              <Text style={styles.successIcon}>✓</Text>
              <Text style={styles.successText}>
                Banking details verified
              </Text>
            </View>
          )}

          {/* No Points Warning */}
          {availablePoints === 0 && (
            <View style={styles.noPointsBanner}>
              <Text style={styles.noPointsIcon}>💰</Text>
              <Text style={styles.noPointsText}>
                No points available to redeem. Scan QR codes to earn points!
              </Text>
            </View>
          )}

          {/* Question Text */}
          <Text style={styles.questionText}>
            How many points would you like to redeem from ₹{availablePoints}?
          </Text>

          {/* Points Input */}
          <TextInput
            style={[
              styles.input,
              (!canRedeem || availablePoints === 0) && styles.disabledInput,
            ]}
            placeholder="Enter Points"
            placeholderTextColor="#999"
            value={points}
            onChangeText={setPoints}
            keyboardType="numeric"
            editable={!isRedeeming && canRedeem && availablePoints > 0}
          />

          {/* Bank Selection Header */}
          <View style={styles.upiHeader}>
            <View style={styles.radioButton}>
              <View style={styles.radioButtonInner} />
            </View>
            <Text style={styles.upiText}>Bank Details</Text>
          </View>

          {/* Form Fields - Pre-filled and Read-only */}
          <View style={styles.formContainer}>
            <View style={styles.formRow}>
              <Text style={styles.label}>Holder name</Text>
              <TextInput
                style={[styles.formInput, styles.readOnlyInput]}
                value={holderName}
                placeholderTextColor={'#999'}
                placeholder="Not available"
                editable={false}
              />
            </View>

            <View style={styles.formRow}>
              <Text style={styles.label}>Bank Name</Text>
              <TextInput
                style={[styles.formInput, styles.readOnlyInput]}
                value={bankName}
                placeholderTextColor={'#999'}
                placeholder="Not available"
                editable={false}
              />
            </View>

            <View style={styles.formRow}>
              <Text style={styles.label}>Branch Name</Text>
              <TextInput
                style={styles.formInput}
                value={branchName}
                onChangeText={setBranchName}
                placeholderTextColor={'#999'}
                placeholder="Enter branch name (optional)"
                editable={!isRedeeming && canRedeem}
              />
            </View>

            <View style={styles.formRow}>
              <Text style={styles.label}>Account no.</Text>
              <TextInput
                style={[styles.formInput, styles.readOnlyInput]}
                value={accountNo}
                placeholderTextColor={'#999'}
                placeholder="Not available"
                editable={false}
              />
            </View>

            <View style={styles.formRow}>
              <Text style={styles.label}>IFSC Code</Text>
              <TextInput
                style={[styles.formInput, styles.readOnlyInput]}
                value={ifscCode}
                placeholderTextColor={'#999'}
                placeholder="Not available"
                editable={false}
              />
            </View>

            {bankingDetails?.benaficeryId && (
              <View style={styles.formRow}>
                <Text style={styles.label}>Beneficiary ID</Text>
                <TextInput
                  style={[styles.formInput, styles.readOnlyInput]}
                  value={bankingDetails.benaficeryId}
                  placeholderTextColor={'#999'}
                  editable={false}
                />
              </View>
            )}
          </View>

          {/* Verification Status */}
          {bankingDetails && (
            <View style={styles.verificationContainer}>
              <View style={styles.verificationRow}>
                <Text style={styles.verificationLabel}>
                  Beneficiary Verified:
                </Text>
                <Text
                  style={[
                    styles.verificationStatus,
                    bankingDetails.isbenverified
                      ? styles.verified
                      : styles.notVerified,
                  ]}
                >
                  {bankingDetails.isbenverified ? '✓ Yes' : '✗ No'}
                </Text>
              </View>
              <View style={styles.verificationRow}>
                <Text style={styles.verificationLabel}>Aadhar Verified:</Text>
                <Text
                  style={[
                    styles.verificationStatus,
                    bankingDetails.isaadharverified
                      ? styles.verified
                      : styles.notVerified,
                  ]}
                >
                  {bankingDetails.isaadharverified ? '✓ Yes' : '✗ No'}
                </Text>
              </View>
            </View>
          )}

          {/* Redeem Button */}
          <TouchableOpacity
            style={[
              styles.redeemButton,
              {
                backgroundColor:
                  isRedeeming || !canRedeem || availablePoints === 0
                    ? '#ccc'
                    : AppStyle.container.backgroundColor,
              },
            ]}
            onPress={handleRedeem}
            disabled={isRedeeming || !canRedeem || availablePoints === 0}
          >
            {isRedeeming ? (
              <View style={styles.buttonContent}>
                <ActivityIndicator size="small" color="#FFFFFF" />
                <Text style={styles.redeemButtonText}>Processing...</Text>
              </View>
            ) : (
              <Text style={styles.redeemButtonText}>
                {!canRedeem
                  ? 'Complete Banking Details First'
                  : availablePoints === 0
                  ? 'No Points Available'
                  : 'Redeem'}
              </Text>
            )}
          </TouchableOpacity>
        </ScrollView>
      )}

      {/* Loading Overlay */}
      {isRedeeming && (
        <View style={styles.loadingOverlay}>
          <View style={styles.loadingCard}>
            <ActivityIndicator size="large" color="#6B46C1" />
            <Text style={styles.loadingOverlayText}>
              Processing Redemption...
            </Text>
          </View>
        </View>
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  centered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: '#666',
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 100,
  },
  statsCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  statRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 15,
  },
  statItem: {
    flex: 1,
    alignItems: 'center',
  },
  statLabel: {
    fontSize: 12,
    color: '#6B7280',
    marginBottom: 4,
    fontWeight: '500',
  },
  statValue: {
    fontSize: 20,
    color: '#1F2937',
    fontWeight: '700',
  },
  availableValue: {
    color: '#10B981',
  },
  scanInfo: {
    backgroundColor: '#F3F4F6',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 5,
  },
  scanText: {
    fontSize: 14,
    color: '#4B5563',
    fontWeight: '500',
  },
  scanValue: {
    color: '#6B46C1',
    fontWeight: '700',
  },
  warningBanner: {
    backgroundColor: '#FFF3CD',
    borderRadius: 12,
    padding: 15,
    marginBottom: 20,
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#FFE69C',
  },
  warningIcon: {
    fontSize: 24,
    marginRight: 10,
  },
  warningText: {
    flex: 1,
    color: '#856404',
    fontSize: 14,
    fontWeight: '500',
  },
  successBanner: {
    backgroundColor: '#D4EDDA',
    borderRadius: 12,
    padding: 15,
    marginBottom: 20,
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#C3E6CB',
  },
  successIcon: {
    fontSize: 24,
    marginRight: 10,
    color: '#155724',
  },
  successText: {
    flex: 1,
    color: '#155724',
    fontSize: 14,
    fontWeight: '500',
  },
  noPointsBanner: {
    backgroundColor: '#FEF3C7',
    borderRadius: 12,
    padding: 15,
    marginBottom: 20,
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#FDE68A',
  },
  noPointsIcon: {
    fontSize: 24,
    marginRight: 10,
  },
  noPointsText: {
    flex: 1,
    color: '#92400E',
    fontSize: 14,
    fontWeight: '500',
  },
  coinContainer: {
    alignItems: 'center',
    marginTop: 20,
    marginBottom: 20,
  },
  coinIcon: {
    fontSize: 60,
  },
  infoBanner: {
    backgroundColor: '#FFB74D',
    borderRadius: 25,
    padding: 15,
    marginBottom: 20,
  },
  infoText: {
    color: '#FFFFFF',
    fontSize: 14,
    textAlign: 'center',
    fontWeight: '500',
  },
  questionText: {
    fontSize: 18,
    color: '#2C2C54',
    textAlign: 'center',
    marginBottom: 20,
    fontWeight: '500',
  },
  input: {
    backgroundColor: '#FFFFFF',
    borderRadius: 15,
    padding: 15,
    fontSize: 16,
    color: '#333',
    marginBottom: 20,
  },
  disabledInput: {
    backgroundColor: '#F5F5F5',
    color: '#999',
  },
  upiHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 15,
  },
  radioButton: {
    width: 24,
    height: 24,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#605e5eff',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
  },
  radioButtonInner: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: '#414141ff',
  },
  upiText: {
    color: '#181717ff',
    fontSize: 18,
    fontWeight: '600',
  },
  formContainer: {
    backgroundColor: '#FFFFFF',
    borderRadius: 15,
    overflow: 'hidden',
    marginBottom: 20,
  },
  formRow: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  label: {
    flex: 0.4,
    padding: 15,
    fontSize: 16,
    color: '#333',
    fontWeight: '500',
    borderRightWidth: 1,
    borderRightColor: '#E0E0E0',
  },
  formInput: {
    flex: 0.6,
    padding: 15,
    fontSize: 16,
    color: '#333',
  },
  readOnlyInput: {
    backgroundColor: '#F8F8F8',
    color: '#666',
  },
  verificationContainer: {
    backgroundColor: '#F8F9FA',
    borderRadius: 12,
    padding: 15,
    marginBottom: 20,
  },
  verificationRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
  },
  verificationLabel: {
    fontSize: 14,
    color: '#495057',
    fontWeight: '500',
  },
  verificationStatus: {
    fontSize: 14,
    fontWeight: '600',
  },
  verified: {
    color: '#28A745',
  },
  notVerified: {
    color: '#DC3545',
  },
  redeemButton: {
    borderRadius: 15,
    padding: 18,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 4.65,
    elevation: 8,
  },
  redeemButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '600',
  },
  buttonContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  loadingOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.7)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 999,
  },
  loadingCard: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 24,
    alignItems: 'center',
    elevation: 5,
  },
  loadingOverlayText: {
    marginTop: 12,
    fontSize: 16,
    fontWeight: '600',
    color: '#1a1a1a',
  },
});

export default Redeem;